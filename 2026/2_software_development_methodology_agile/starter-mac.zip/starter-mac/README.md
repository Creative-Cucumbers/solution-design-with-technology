# 演習用スターター（Mac / Linux 用）

このフォルダを **Antigravity IDE で開いて**ください（**ファイル → フォルダーを開く**）。内部スクリプトは シェル 版です。

チャットで `/speckit-` と打ってコマンド一覧が出れば準備完了です。

## 授業での流れ

1. 受け入れ条件を自分の言葉で書く（ここは人間の仕事）
2. `/speckit-specify` — 仕様書を作る → **中身をレビューして直す**
3. `/speckit-plan` → `/speckit-tasks` — 計画とタスクに落とす
4. `/speckit-implement` — 実装する
5. 受け入れ条件を1つずつ確認する

作られた `spec.md` / `plan.md` / `tasks.md` は `specs/` の下に残ります。提出物になるので消さないでください。

詳細は [../README.md](../README.md) を参照してください。
